import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.List;
import java.util.*;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

/**
 * Online Quiz Swing Application
 * * This application is a graphical user interface implementation of the Online Quiz Management System
 * using the core logic (User, Quiz, Question classes) from the original console application.
 * It uses CardLayout to switch between different views (Login, Quiz List, Take Quiz).
 */
public class QuizApp extends JFrame {

    // --- Data Models (Adapted from original console app) ---

    // User class (Serializable for persistence)
    static class User implements Serializable {
        private static final long serialVersionUID = 20241105001L;
        private String username;
        private String password;
        private int score;
        private int quizzesTaken;
        
        public User(String username, String password) {
            this.username = username;
            this.password = password;
            this.score = 0;
            this.quizzesTaken = 0;
        }
        
        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public int getScore() { return score; }
        public int getQuizzesTaken() { return quizzesTaken; }

        public void updateScore(int points) { this.score += points; }
        public void incrementQuizzesTaken() { this.quizzesTaken++; }
    }

    // Question class (Serializable for persistence)
    static class Question implements Serializable {
        private static final long serialVersionUID = 20241105002L;
        private String questionText;
        private String[] options;
        private int correctAnswer; // 0-based index
        private int points;
        
        public Question(String questionText, String[] options, int correctAnswer, int points) {
            this.questionText = questionText;
            this.options = options;
            this.correctAnswer = correctAnswer;
            this.points = points;
        }
        
        public String getQuestionText() { return questionText; }
        public String[] getOptions() { return options; }
        public int getCorrectAnswer() { return correctAnswer; }
        public int getPoints() { return points; }
    }

    // Quiz class (Serializable for persistence)
    static class Quiz implements Serializable {
        private static final long serialVersionUID = 20241105003L;
        private String title;
        private List<Question> questions;
        private int timeLimit; // minutes
        private int totalPoints;
        
        public Quiz(String title, int timeLimit) {
            this.title = title;
            this.timeLimit = timeLimit;
            this.questions = new ArrayList<>();
            this.totalPoints = 0;
        }
        
        public String getTitle() { return title; }
        public List<Question> getQuestions() { return questions; }
        public int getTimeLimit() { return timeLimit; }
        public int getTotalPoints() { return totalPoints; }
        
        public void addQuestion(Question question) {
            questions.add(question);
            totalPoints += question.getPoints();
        }
    }

    // --- Core Application State and Data Management ---

    private List<User> users = new ArrayList<>();
    private List<Quiz> quizzes = new ArrayList<>();
    private User currentUser;
    
    private static final String USERS_FILE = "swing_users.dat";
    private static final String QUIZZES_FILE = "swing_quizzes.dat";
    
    // UI components and layout
    private JPanel cardPanel;
    private CardLayout cardLayout = new CardLayout();
    
    // View names
    private static final String LOGIN_VIEW = "Login";
    private static final String QUIZ_LIST_VIEW = "QuizList";
    private static final String TAKE_QUIZ_VIEW = "TakeQuiz";

    public QuizApp() {
        setTitle("Online Quiz System (Swing)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null); // Center the window

        loadData();
        setupSampleData(); // Ensure there's always a sample quiz/user
        
        cardPanel = new JPanel(cardLayout);
        
        // Add all views to the card panel
        cardPanel.add(createLoginPanel(), LOGIN_VIEW);
        
        // Add QuizList and TakeQuiz panels on login
        // They will be initialized/updated when the user logs in
        
        add(cardPanel);
        setVisible(true);
    }
    
    // --- Data Persistence Methods ---

    @SuppressWarnings("unchecked")
    private void loadData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(USERS_FILE))) {
            users = (List<User>) ois.readObject();
        } catch (FileNotFoundException ignored) {
            // New app start, files don't exist
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading user data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(QUIZZES_FILE))) {
            quizzes = (List<Quiz>) ois.readObject();
        } catch (FileNotFoundException ignored) {
            // New app start, files don't exist
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading quiz data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USERS_FILE))) {
            oos.writeObject(users);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving user data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(QUIZZES_FILE))) {
            oos.writeObject(quizzes);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving quiz data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setupSampleData() {
        if (users.isEmpty()) {
            users.add(new User("admin", "password"));
        }
        if (quizzes.isEmpty()) {
            Quiz sampleQuiz = new Quiz("General Knowledge Quiz", 5);
            sampleQuiz.addQuestion(new Question("What is the capital of France?", new String[]{"Berlin", "Madrid", "Paris", "Rome"}, 2, 10));
            sampleQuiz.addQuestion(new Question("What is 2 + 2?", new String[]{"3", "4", "5", "6"}, 1, 5));
            quizzes.add(sampleQuiz);
        }
    }

    // --- UI Panels/Views ---

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255)); // AliceBlue
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Online Quiz System Login", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(title, gbc);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(userLabel, gbc);

        JTextField userText = new JTextField(20);
        userText.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(userText, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(passwordLabel, gbc);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(passwordText, gbc);

        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBackground(new Color(60, 179, 113)); // MediumSeaGreen
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        JButton registerButton = new JButton("Register");
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setBackground(new Color(70, 130, 180)); // SteelBlue
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        panel.add(registerButton, gbc);

        loginButton.addActionListener(e -> {
            String username = userText.getText();
            String password = new String(passwordText.getPassword());
            if (performLogin(username, password)) {
                // Clear fields
                userText.setText("");
                passwordText.setText("");
                
                // Switch to Quiz List view
                initializeQuizListPanel();
                cardLayout.show(cardPanel, QUIZ_LIST_VIEW);
            } else {
                JOptionPane.showMessageDialog(panel, "Invalid Username or Password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        registerButton.addActionListener(e -> {
            String username = userText.getText();
            String password = new String(passwordText.getPassword());
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Username and Password cannot be empty.", "Registration Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (performRegistration(username, password)) {
                JOptionPane.showMessageDialog(panel, "Registration successful! You can now log in.", "Success", JOptionPane.INFORMATION_MESSAGE);
                userText.setText("");
                passwordText.setText("");
            } else {
                JOptionPane.showMessageDialog(panel, "Username already exists.", "Registration Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    private JPanel createQuizListPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(new Color(245, 245, 220)); // Beige

        JLabel welcomeLabel = new JLabel("", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(welcomeLabel, BorderLayout.NORTH);

        JList<Quiz> quizJList = new JList<>();
        quizJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        quizJList.setFont(new Font("Monospaced", Font.PLAIN, 14));
        quizJList.setCellRenderer(new QuizListRenderer());
        JScrollPane scrollPane = new JScrollPane(quizJList);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        bottomPanel.setBackground(panel.getBackground());

        JButton takeQuizButton = new JButton("Take Selected Quiz");
        takeQuizButton.setFont(new Font("Arial", Font.BOLD, 14));
        takeQuizButton.setBackground(new Color(0, 128, 0)); // Green
        takeQuizButton.setForeground(Color.WHITE);
        
        JButton leaderboardButton = new JButton("Leaderboard");
        leaderboardButton.setFont(new Font("Arial", Font.BOLD, 14));
        leaderboardButton.setBackground(new Color(255, 165, 0)); // Orange
        leaderboardButton.setForeground(Color.BLACK);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setBackground(new Color(220, 20, 60)); // Crimson
        logoutButton.setForeground(Color.WHITE);

        bottomPanel.add(takeQuizButton);
        bottomPanel.add(leaderboardButton);
        bottomPanel.add(logoutButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        // Custom component to store the list data model
        panel.setName("QuizListPanel");

        panel.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                if (currentUser != null) {
                    welcomeLabel.setText("Welcome, " + currentUser.getUsername() + " | Total Score: " + currentUser.getScore());
                }
                DefaultListModel<Quiz> model = new DefaultListModel<>();
                for (Quiz quiz : quizzes) {
                    model.addElement(quiz);
                }
                quizJList.setModel(model);
            }
        });

        takeQuizButton.addActionListener(e -> {
            Quiz selectedQuiz = quizJList.getSelectedValue();
            if (selectedQuiz != null) {
                initializeTakeQuizPanel(selectedQuiz);
                cardLayout.show(cardPanel, TAKE_QUIZ_VIEW);
            } else {
                JOptionPane.showMessageDialog(panel, "Please select a quiz to take.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        });

        leaderboardButton.addActionListener(e -> showLeaderboard());

        logoutButton.addActionListener(e -> performLogout());

        return panel;
    }

    // Custom Cell Renderer for better Quiz list display
    class QuizListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Quiz quiz) {
                setText(String.format("<html><b>%s</b><br/><small>Questions: %d | Time: %d mins | Points: %d</small></html>", 
                        quiz.getTitle(), 
                        quiz.getQuestions().size(), 
                        quiz.getTimeLimit(), 
                        quiz.getTotalPoints()));
                
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY),
                    BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
            return this;
        }
    }

    /**
     * Helper method to check if a component with a given name exists in the card panel.
     * This replaces the incorrect use of cardPanel.getComponent(String name).
     */
    private boolean isComponentPresent(String name) {
        for (Component comp : cardPanel.getComponents()) {
            if (name.equals(comp.getName())) {
                return true;
            }
        }
        return false;
    }

    private void initializeQuizListPanel() {
        // Fix: Use isComponentPresent to check if the panel has been added.
        if (!isComponentPresent(QUIZ_LIST_VIEW)) {
            JPanel quizListPanel = createQuizListPanel();
            quizListPanel.setName(QUIZ_LIST_VIEW); // Set the name to be checkable later
            cardPanel.add(quizListPanel, QUIZ_LIST_VIEW);
        }
    }

    private void initializeTakeQuizPanel(Quiz quiz) {
        // Fix: Use isComponentPresent to check if the TAKE_QUIZ_VIEW panel is already present.
        // It's removed and re-added every time since it holds state specific to the current quiz session.
        if (isComponentPresent(TAKE_QUIZ_VIEW)) {
            // Find and remove the existing panel by name
            for (Component comp : cardPanel.getComponents()) {
                if (TAKE_QUIZ_VIEW.equals(comp.getName())) {
                    cardPanel.remove(comp);
                    break;
                }
            }
        }
        
        TakeQuizPanel takeQuizPanel = new TakeQuizPanel(quiz);
        takeQuizPanel.setName(TAKE_QUIZ_VIEW); // Set the name for later removal/check
        cardPanel.add(takeQuizPanel, TAKE_QUIZ_VIEW);
    }
    
    // --- Authentication and Logic ---

    private boolean performLogin(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                currentUser = user;
                return true;
            }
        }
        return false;
    }

    private boolean performRegistration(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return false; // Username exists
            }
        }
        users.add(new User(username, password));
        saveData();
        return true;
    }

    private void performLogout() {
        currentUser = null;
        cardLayout.show(cardPanel, LOGIN_VIEW);
        JOptionPane.showMessageDialog(this, "You have been logged out.", "Logout", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showLeaderboard() {
        if (users.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No users found for the leaderboard.", "Leaderboard", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Sort users by score (descending)
        users.sort((u1, u2) -> Integer.compare(u2.getScore(), u1.getScore()));

        StringBuilder sb = new StringBuilder("<html><body style='width: 300px; font-family: Arial;'>");
        sb.append("<h2 style='text-align: center; color: #333;'>Leaderboard</h2>");
        sb.append("<table border='1' cellpadding='5' cellspacing='0' style='width: 100%; border-collapse: collapse;'>");
        sb.append("<tr style='background-color: #f0f0f0;'><th>Rank</th><th>Username</th><th>Score</th><th>Quizzes</th></tr>");

        int rank = 1;
        for (User u : users) {
            sb.append(String.format("<tr><td style='text-align: center;'>%d</td><td>%s</td><td style='text-align: center;'>%d</td><td style='text-align: center;'>%d</td></tr>", 
                rank++, u.getUsername(), u.getScore(), u.getQuizzesTaken()));
        }
        sb.append("</table></body></html>");
        
        // Show in a scrollable JOptionPane
        JEditorPane editorPane = new JEditorPane("text/html", sb.toString());
        editorPane.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(editorPane);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Leaderboard", JOptionPane.PLAIN_MESSAGE);
    }

    // --- Inner Panel for Quiz Taking ---

    private class TakeQuizPanel extends JPanel {
        private final Quiz quiz;
        private int currentQuestionIndex = 0;
        private int currentQuizScore = 0;
        private final List<Question> questions;
        
        private final JLabel timerLabel = new JLabel();
        private final JLabel questionIndexLabel = new JLabel();
        private final JTextArea questionText = new JTextArea();
        private final ButtonGroup optionsGroup = new ButtonGroup();
        private final JRadioButton[] optionButtons = new JRadioButton[4];
        private final JButton nextButton = new JButton("Next Question");
        private Timer timer;

        public TakeQuizPanel(Quiz quiz) {
            this.quiz = quiz;
            this.questions = quiz.getQuestions();
            setLayout(new BorderLayout(10, 10));
            setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            setBackground(new Color(255, 255, 240)); // Ivory

            // Top Panel (Timer, Title, Info)
            JPanel topPanel = new JPanel(new BorderLayout());
            topPanel.setOpaque(false);
            
            timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
            timerLabel.setForeground(new Color(220, 20, 60)); // Crimson
            
            JLabel quizTitle = new JLabel(quiz.getTitle(), SwingConstants.CENTER);
            quizTitle.setFont(new Font("Arial", Font.BOLD, 24));
            
            questionIndexLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            
            topPanel.add(timerLabel, BorderLayout.WEST);
            topPanel.add(quizTitle, BorderLayout.CENTER);
            topPanel.add(questionIndexLabel, BorderLayout.EAST);
            add(topPanel, BorderLayout.NORTH);

            // Center Panel (Question Text and Options)
            JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
            centerPanel.setOpaque(false);
            
            questionText.setEditable(false);
            questionText.setLineWrap(true);
            questionText.setWrapStyleWord(true);
            questionText.setFont(new Font("Arial", Font.BOLD, 18));
            questionText.setOpaque(false);
            centerPanel.add(new JScrollPane(questionText), BorderLayout.NORTH);

            JPanel optionsPanel = new JPanel();
            optionsPanel.setLayout(new BoxLayout(optionsPanel, BoxLayout.Y_AXIS));
            optionsPanel.setBorder(BorderFactory.createTitledBorder("Select an Answer"));
            optionsPanel.setOpaque(false);

            for (int i = 0; i < 4; i++) {
                optionButtons[i] = new JRadioButton();
                optionButtons[i].setFont(new Font("Arial", Font.PLAIN, 16));
                optionButtons[i].setOpaque(false);
                optionsGroup.add(optionButtons[i]);
                optionsPanel.add(optionButtons[i]);
            }
            
            centerPanel.add(optionsPanel, BorderLayout.CENTER);
            add(centerPanel, BorderLayout.CENTER);

            // Bottom Panel (Next Button)
            JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            bottomPanel.setOpaque(false);
            nextButton.setFont(new Font("Arial", Font.BOLD, 16));
            nextButton.setBackground(new Color(60, 179, 113));
            nextButton.setForeground(Color.WHITE);
            bottomPanel.add(nextButton);
            add(bottomPanel, BorderLayout.SOUTH);

            // Event Listeners
            nextButton.addActionListener(e -> processAnswerAndNext());

            // Start Quiz
            displayQuestion();
            startTimer();
        }

        private void startTimer() {
            int totalSeconds = quiz.getTimeLimit() * 60;
            final long endTime = System.currentTimeMillis() + (long)totalSeconds * 1000;
            
            timer = new Timer();
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    long remainingTime = endTime - System.currentTimeMillis();
                    if (remainingTime <= 0) {
                        SwingUtilities.invokeLater(() -> finishQuiz(true));
                        timer.cancel();
                        return;
                    }
                    long minutes = TimeUnit.MILLISECONDS.toMinutes(remainingTime);
                    long seconds = TimeUnit.MILLISECONDS.toSeconds(remainingTime) - TimeUnit.MINUTES.toSeconds(minutes);
                    
                    SwingUtilities.invokeLater(() -> {
                        timerLabel.setText(String.format("Time Left: %02d:%02d", minutes, seconds));
                        if (minutes == 0 && seconds <= 30) {
                            timerLabel.setForeground(Color.RED);
                        }
                    });
                }
            }, 0, 1000); // Update every second
        }

        private void displayQuestion() {
            if (currentQuestionIndex < questions.size()) {
                Question q = questions.get(currentQuestionIndex);

                questionIndexLabel.setText(String.format("Q: %d/%d | Pts: %d", 
                    currentQuestionIndex + 1, questions.size(), q.getPoints()));
                questionText.setText(q.getQuestionText());

                optionsGroup.clearSelection();
                for (int i = 0; i < q.getOptions().length; i++) {
                    optionButtons[i].setText(q.getOptions()[i]);
                    optionButtons[i].setEnabled(true);
                }
                
                if (currentQuestionIndex == questions.size() - 1) {
                    nextButton.setText("Finish Quiz");
                }
            } else {
                finishQuiz(false);
            }
        }

        private void processAnswerAndNext() {
            Question q = questions.get(currentQuestionIndex);
            int selectedAnswer = -1;
            
            for (int i = 0; i < optionButtons.length; i++) {
                if (optionButtons[i].isSelected()) {
                    selectedAnswer = i;
                    break;
                }
            }

            // Check if the selected answer is correct
            if (selectedAnswer == q.getCorrectAnswer()) {
                currentQuizScore += q.getPoints();
            }

            currentQuestionIndex++;
            displayQuestion();
        }

        private void finishQuiz(boolean timedOut) {
            if (timer != null) {
                timer.cancel();
            }
            
            if (currentUser != null) {
                currentUser.updateScore(currentQuizScore);
                currentUser.incrementQuizzesTaken();
                saveData();
            }

            String message = (timedOut ? "Time's up! " : "Quiz Complete! ") 
                             + String.format("\nYour score for this quiz: %d out of %d.", 
                                 currentQuizScore, quiz.getTotalPoints())
                             + String.format("\nYour total accumulated score is now: %d", 
                                 currentUser != null ? currentUser.getScore() : currentQuizScore);

            JOptionPane.showMessageDialog(QuizApp.this, message, "Quiz Results", JOptionPane.INFORMATION_MESSAGE);
            
            // Go back to the quiz list view
            cardLayout.show(cardPanel, QUIZ_LIST_VIEW);
        }
    }

    // --- Main Method ---

    public static void main(String[] args) {
        // Run the application on the Event Dispatch Thread
        SwingUtilities.invokeLater(QuizApp::new);
    }
}
